<?php

namespace OCA\FederatedGroups\helpers;

interface IDomainHelper
{
    public function getOurDomain(): string;
}